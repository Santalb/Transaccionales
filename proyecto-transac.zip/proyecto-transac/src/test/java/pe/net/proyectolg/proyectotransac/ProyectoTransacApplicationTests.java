package pe.net.proyectolg.proyectotransac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoTransacApplicationTests {

	@Test
	void contextLoads() {
	}

}
