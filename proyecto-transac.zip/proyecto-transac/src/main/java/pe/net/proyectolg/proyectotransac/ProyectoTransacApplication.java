package pe.net.proyectolg.proyectotransac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoTransacApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoTransacApplication.class, args);
	}

}
